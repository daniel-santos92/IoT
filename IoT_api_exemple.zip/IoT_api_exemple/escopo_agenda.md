/iot_api_exemple
│
├── app.py               # O arquivo principal da aplicação Flask
├── .env                 # O arquivo com as variáveis de ambiente
├── /templates
│   └── index.html       # O arquivo HTML que será servido